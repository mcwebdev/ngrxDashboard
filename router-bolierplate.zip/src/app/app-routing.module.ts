import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PageOneComponent } from './components/page-one/page-one.component';
import { PageTwoComponent } from './components/page-two/page-two.component';
import { PageThreeComponent } from './components/page-three/page-three.component';

const routes: Routes = [
  { path: 'page-one', component: PageOneComponent, data: { animation: 'isLeft' } },
  { path: 'page-two', component: PageTwoComponent, data: { animation: 'isRight' } },
  { path: 'page-three', component: PageThreeComponent, data: { animation: 'isLeft' } },
  { path: '', redirectTo: '/page-one', pathMatch: 'full' }  // Redirect to `page-one` as the default route
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
