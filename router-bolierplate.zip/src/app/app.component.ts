import { Component } from '@angular/core';
import { slider, fadeInAnimation } from './route-animations';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  animations: [slider, fadeInAnimation] // Add this line
})
export class AppComponent {
  title = 'routerAnimations';
  prepareRoute(outlet: any) {
    return outlet && outlet.activatedRouteData && outlet.activatedRouteData['animation'];
  }
}
